# Sistema para agendamento de defesas de TCC

Esse é o arquivo readme.md, onde ficarão definidas particularidades da codificação do projeto, como fazer para clonar o projeto, quais dependências, etc...

## Project Canvas Online

Nesse projeto estamos utilizando o Canvas como o "Termo de Abertura do Projeto(TAP)". Ele contém uma visão geral do sistema a ser desenvolvido.


Segue abaixo o link para acesso ao Canvas direto pela plataforma.

[ProjectCanvas.Online](http://app.projectcanvas.online/#/board/X53Xv1ELBX562MSCksgRVL5dDHDAmUF91X093qaK44=/public)

Caso não seja possível visualizar através do link acima segue abaixo links para o formato PDF.

[ProjectCanvas - versão 1](Project_Canvas_v1.pdf)

[ProjectCanvas - versão 2](Project_Canvas_v2.pdf)
